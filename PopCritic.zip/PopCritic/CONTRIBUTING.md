# Contributing

Thank you for your interest in contributing, if you feel that any feature should be added, feel free to open an issue with the feature request, If you find any bug, or vulnerability, you may contact us, or open an issue if it can be resolved.

Any other contributions are welcome, just create a PR with suggested changes, we would be glad to see that.
