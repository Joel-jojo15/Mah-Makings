self.addEventListener('install', function(event) {});
self.addEventListener('activate', function(event) {});